#define BLYNK_TEMPLATE_ID "TMPL6I3HKh2dP"
#define BLYNK_TEMPLATE_NAME "Sistem Hidroponik"
#define BLYNK_AUTH_TOKEN "8IdHjfpKhrbEgZSmZmpyFgmLFLkknuhK"

#define BLYNK_PRINT Serial
#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <math.h>  // Fungsi pow() untuk perhitungan TDS

// ================= PIN CONFIGURATION =================
#define PH_PIN 34
#define EC_PIN 36
#define TRIG_PIN 5
#define ECHO_PIN 18
#define PUMP_PIN 23
#define LED_RED_PIN 2
#define LED_GREEN_PIN 4
#define BUZZER_PIN 17

// Relay
#define RELAY_ON HIGH
#define RELAY_OFF LOW

// ================= KALIBRASI SENSOR pH & TDS =================
const float TEGANGAN_PH7 = 2.50;
const float TEGANGAN_PH4 = 3.00;
const float TEGANGAN_ADC = 3.30;
const int ADC_MAKS = 4095;
const float SUHU_AIR_C = 25.0;

// ================= AMBANG BATAS =================
const float PH_MIN = 5.5;
const float PH_MAX = 6.5;
const int PPM_MIN = 800;
const int WATER_LEVEL_MIN_CM = 10;
const float TANK_HEIGHT_CM = 30.0;

// Batas air melebihi kapasitas (ukur jarak sensor ke air saat tandon penuh, lalu sesuaikan)
const float JARAK_AIR_PENUH_CM = 5.0;   // jarak <= nilai ini = air melebihi kapasitas
const float HISTERESIS_CM = 1.0;        // air harus turun sampai batas + nilai ini baru dianggap aman
const int JUMLAH_BACA_KONFIRMASI = 2;   // jumlah pembacaan berturut-turut sebelum status berubah

// ================= WIFI =================
char ssid[] = "Suepp";
char pass[] = "Narendra";

BlynkTimer timer;

// ================= VARIABEL SENSOR =================
float phValue = 0;
int ppmValue = 0;
float waterDistance = -1;
float levelAir = 0;

bool pompaNutrisiAktif = false;
bool isAlert = false;

// Status air melebihi kapasitas (menentukan LED merah dan buzzer)
bool airMelebihi = false;
int hitungMelebihi = 0;
int hitungNormal = 0;

bool modeManual = false;
bool manualPompa = false;

String statusPH = "Membaca sensor";
String statusLevelAir = "Membaca sensor";
String pesanPeringatan = "Memulai sistem";

// Variable penanda perubahan kondisi alert agar event hanya dikirim sekali saat terjadi perubahan
bool lastAlertState = false;

// ================= BLYNK =================
BLYNK_WRITE(V7) {
  modeManual = param.asInt();
}

BLYNK_WRITE(V5) {
  manualPompa = param.asInt();
}

BLYNK_CONNECTED() {
  Blynk.syncVirtual(V5, V7);
}

// Buzzer berbunyi berselang-seling saat ada peringatan
void kontrolBuzzer(bool peringatan) {
  static unsigned long waktuUbah = 0;
  static bool bunyi = false;

  if (!peringatan) {
    bunyi = false;
    noTone(BUZZER_PIN);
    waktuUbah = millis();
    return;
  }

  if (millis() - waktuUbah >= 500) {
    waktuUbah = millis();
    bunyi = !bunyi;

    if (bunyi) {
      tone(BUZZER_PIN, 2000);
    } else {
      noTone(BUZZER_PIN);
    }
  }
}

// ================= SENSOR ULTRASONIK =================
float readWaterLevel() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);

  if (duration == 0) {
    return -1;
  }

  return duration * 0.0343 / 2.0;
}

// ================= KIRIM DATA BLYNK =================
void kirimDataBlynk() {
  if (!Blynk.connected()) return;

  Blynk.virtualWrite(V0, phValue);
  Blynk.virtualWrite(V1, ppmValue);
  Blynk.virtualWrite(V2, levelAir);
  Blynk.virtualWrite(V3, waterDistance);
  Blynk.virtualWrite(V4, pompaNutrisiAktif ? 1 : 0);
  Blynk.virtualWrite(V6, isAlert ? 0 : 1);
  Blynk.virtualWrite(V10, statusPH);
  Blynk.virtualWrite(V11, statusLevelAir);
  Blynk.virtualWrite(V12, pesanPeringatan);

  // Menuliskan log aktivitas (Events) ke platform Blynk saat ada peringatan baru
  if (isAlert && !lastAlertState) {
    Blynk.logEvent("peringatan_sistem", pesanPeringatan);
  }
  lastAlertState = isAlert;
}

// ================= PROSES SENSOR =================
void prosesSensor() {

  // 1. Membaca tegangan sensor pH dengan rata-rata 10 sampel
  long jumlahPH = 0;
  long jumlahTDS = 0;
  for (int i = 0; i < 10; i++) {
    jumlahPH += analogRead(PH_PIN);
    jumlahTDS += analogRead(EC_PIN);
    delay(5);
  }

  float phRaw = jumlahPH / 10.0;
  float phVolt = phRaw * TEGANGAN_ADC / ADC_MAKS;

  // Perbaikan sintaks matematika pada rumus pH
  if (fabs(TEGANGAN_PH7 - TEGANGAN_PH4) > 0.001) {
    float kemiringanPH = (7.0 - 4.0) / (TEGANGAN_PH7 - TEGANGAN_PH4);
    phValue = 7.0 + (phVolt - TEGANGAN_PH7) * kemiringanPH;
  }
  phValue = constrain(phValue, 0.0, 14.0);

  // 2. Membaca sensor TDS (analog) dan menghitung perkiraan ppm.
  float tdsRaw = jumlahTDS / 10.0;
  float tdsVolt = tdsRaw * TEGANGAN_ADC / ADC_MAKS;
  float kompensasiSuhu = 1.0 + 0.02 * (SUHU_AIR_C - 25.0);
  float teganganKompensasi = tdsVolt / kompensasiSuhu;
  
  // Perbaikan sintaks matematika pada rumus TDS
  float tdsHitung = (133.42 * pow(teganganKompensasi, 3)
                    - 255.86 * pow(teganganKompensasi, 2)
                    + 857.39 * teganganKompensasi) * 0.5;
  ppmValue = (int)constrain(tdsHitung, 0.0, 5000.0);

  // 3. Membaca jarak permukaan air
  waterDistance = readWaterLevel();

  if (waterDistance >= 0) {
    levelAir = (TANK_HEIGHT_CM - waterDistance) / TANK_HEIGHT_CM * 100.0;
    levelAir = constrain(levelAir, 0.0, 100.0);
  } else {
    levelAir = 0;
  }

  // 3b. Deteksi air melebihi kapasitas (histeresis dan konfirmasi berulang)
  // Jika sensor gagal membaca (-1), status sebelumnya dipertahankan.
  if (waterDistance >= 0) {
    if (!airMelebihi) {
      if (waterDistance <= JARAK_AIR_PENUH_CM) {
        hitungMelebihi++;
        if (hitungMelebihi >= JUMLAH_BACA_KONFIRMASI) {
          airMelebihi = true;
          hitungNormal = 0;
        }
      } else {
        hitungMelebihi = 0;
      }
    } else {
      if (waterDistance >= JARAK_AIR_PENUH_CM + HISTERESIS_CM) {
        hitungNormal++;
        if (hitungNormal >= JUMLAH_BACA_KONFIRMASI) {
          airMelebihi = false;
          hitungMelebihi = 0;
        }
      } else {
        hitungNormal = 0;
      }
    }
  }

  // 4. Status pH
  if (phValue < PH_MIN) {
    statusPH = "pH terlalu rendah";
  } else if (phValue > PH_MAX) {
    statusPH = "pH terlalu tinggi";
  } else {
    statusPH = "pH ideal";
  }

  // 5. Status ketinggian air
  if (airMelebihi) {
    statusLevelAir = "Air melebihi kapasitas";
  } else if (waterDistance < 0) {
    statusLevelAir = "Sensor gagal membaca";
  } else if (waterDistance > WATER_LEVEL_MIN_CM) {
    statusLevelAir = "Air surut";
  } else {
    statusLevelAir = "Air cukup";
  }

  // 6. Kontrol pompa otomatis/manual
  bool pompaOn = modeManual ? manualPompa : (ppmValue < PPM_MIN);

  digitalWrite(PUMP_PIN, pompaOn ? RELAY_ON : RELAY_OFF);

  pompaNutrisiAktif = pompaOn;

  // 7. Menentukan peringatan
  isAlert = false;
  pesanPeringatan = "Sistem normal";

  if (airMelebihi) {
    isAlert = true;
    pesanPeringatan = "Air melebihi kapasitas";
  } else if (waterDistance < 0) {
    isAlert = true;
    pesanPeringatan = "Periksa sensor ultrasonik";
  } else if (waterDistance > WATER_LEVEL_MIN_CM) {
    isAlert = true;
    pesanPeringatan = "Air tandon surut";
  } else if (phValue < PH_MIN || phValue > PH_MAX) {
    isAlert = true;
    pesanPeringatan = "pH di luar batas ideal";
  } else if (ppmValue < PPM_MIN) {
    isAlert = true;
    pesanPeringatan = "PPM rendah - pompa nutrisi aktif";
  }

  // 8. LED indikator: merah hanya saat air melebihi kapasitas, selain itu hijau
  if (airMelebihi) {
    digitalWrite(LED_RED_PIN, HIGH);
    digitalWrite(LED_GREEN_PIN, LOW);
  } else {
    digitalWrite(LED_RED_PIN, LOW);
    digitalWrite(LED_GREEN_PIN, HIGH);
  }

  // 9. Buzzer dikontrol di loop() agar bunyi putus-putus tepat waktu

  // 10. Serial Monitor
  Serial.print("pH tegangan: ");
  Serial.print(phVolt, 3);
  Serial.print(" V | pH: ");
  Serial.print(phValue, 1);

  Serial.print(" | TDS tegangan: ");
  Serial.print(tdsVolt, 3);
  Serial.print(" V | TDS: ");
  Serial.print(ppmValue);

  Serial.print(" PPM | Jarak: ");
  Serial.print(waterDistance, 1);

  Serial.print(" cm | Level: ");
  Serial.print(levelAir, 1);

  Serial.print("% | Pompa: ");
  Serial.print(pompaNutrisiAktif ? "ON" : "OFF");

  Serial.print(" | Mode: ");
  Serial.print(modeManual ? "MANUAL" : "AUTO");

  Serial.print(" | Air melebihi: ");
  Serial.print(airMelebihi ? "YA" : "TIDAK");

  Serial.print(" | Status: ");
  Serial.println(isAlert ? "ALERT" : "NORMAL");

  // 11. Mengirim data ke Blynk
  kirimDataBlynk();
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);

  pinMode(PUMP_PIN, OUTPUT);
  pinMode(LED_RED_PIN, OUTPUT);
  pinMode(LED_GREEN_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  digitalWrite(PUMP_PIN, RELAY_OFF);
  digitalWrite(LED_RED_PIN, LOW);
  digitalWrite(LED_GREEN_PIN, LOW);
  noTone(BUZZER_PIN);

  // ADC ESP32 (12-bit, input analog maksimal sekitar 3.3 V)
  analogReadResolution(12);
  analogSetPinAttenuation(PH_PIN, ADC_11db);
  analogSetPinAttenuation(EC_PIN, ADC_11db);

  // WiFi
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, pass);

  Serial.print("Menyambung ke WiFi...");

  unsigned long mulai = millis();

  while (WiFi.status() != WL_CONNECTED && millis() - mulai < 20000) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi tersambung");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi belum tersambung");
  }

  Blynk.config(BLYNK_AUTH_TOKEN, "sgp1.blynk.cloud", 8080);

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Menghubungkan ke Blynk...");

    if (Blynk.connect(10000)) {
      Serial.println("Blynk ONLINE");
    } else {
      Serial.println("Blynk OFFLINE");
    }
  }

  // Proses sensor setiap 2 detik
  timer.setInterval(2000L, prosesSensor);

  // Pembacaan awal
  prosesSensor();
}

// ================= LOOP =================
void loop() {
  static unsigned long terakhirCoba = 0;

  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - terakhirCoba >= 10000) {
      terakhirCoba = millis();

      Serial.println("Mencoba menyambungkan WiFi...");
      WiFi.disconnect();
      WiFi.begin(ssid, pass);
    }
  } else {
    Blynk.run();
  }

  timer.run();

  // Buzzer hanya berbunyi saat air melebihi kapasitas
  kontrolBuzzer(airMelebihi);
}